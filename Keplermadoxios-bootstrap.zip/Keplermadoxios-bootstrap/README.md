# Kepleræ iOS

Base nativa em SwiftUI para portar o Kepleræ Android para iOS 27.

## Estado desta etapa

- Nome exibido: **Kepleræ**
- Versão: **1.0**
- SwiftUI nativo
- Liquid Glass com controle de intensidade visual em roda/scroll
- Áreas iniciais: Aulas, PDFs, Áudios e Dashboard
- Workflow GitHub Actions para gerar `Keplerae-1.0-unsigned.ipa`
- Assinatura desabilitada no build para permitir assinatura externa posterior

## Próxima etapa

Portar a lógica funcional do Android a partir de `flubdugnton-rgb/Keplermadox` (`Keplerae-1.0.1.zip`), mantendo a lógica e substituindo a interface Android pela camada nativa SwiftUI.

## Build

O workflow usa o runner `xcode-27`, instala XcodeGen caso necessário, gera o `.xcodeproj`, compila para `iphoneos` sem assinatura e empacota o `.app` em um IPA.
