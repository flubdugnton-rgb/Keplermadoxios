import SwiftUI

@main
struct KepleraeApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Início", systemImage: "house.fill")
                }

            SettingsView()
                .tabItem {
                    Label("Ajustes", systemImage: "slider.horizontal.3")
                }
        }
    }
}

struct HomeView: View {
    @AppStorage("glassIntensityPercent") private var glassIntensityPercent = 75

    private let sections: [StudySection] = [
        .init(title: "Aulas", subtitle: "Vídeos e conteúdos", icon: "play.rectangle.fill"),
        .init(title: "PDFs", subtitle: "Materiais de estudo", icon: "doc.text.fill"),
        .init(title: "Áudios", subtitle: "Conteúdo em áudio", icon: "headphones"),
        .init(title: "Dashboard", subtitle: "Seu progresso", icon: "chart.xyaxis.line")
    ]

    private var intensity: Double {
        Double(glassIntensityPercent) / 100.0
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AmbientBackground()

                ScrollView {
                    VStack(alignment: .leading, spacing: 24) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Kepleræ")
                                .font(.system(size: 38, weight: .bold, design: .rounded))
                            Text("Seu espaço de estudos")
                                .font(.headline)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.horizontal, 4)

                        GlassEffectContainer(spacing: 18) {
                            LazyVGrid(
                                columns: [GridItem(.flexible()), GridItem(.flexible())],
                                spacing: 16
                            ) {
                                ForEach(sections) { section in
                                    NavigationLink {
                                        StudySectionView(section: section)
                                    } label: {
                                        StudyCard(section: section, intensity: intensity)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }

                        VStack(alignment: .leading, spacing: 12) {
                            Label("Matérias", systemImage: "books.vertical.fill")
                                .font(.title3.bold())

                            SubjectRow(title: "Fisioterapia", icon: "figure.walk")
                            SubjectRow(title: "Português", icon: "text.book.closed.fill")
                            SubjectRow(title: "Matemática e Raciocínio Lógico", icon: "function")
                            SubjectRow(title: "HU — Legislação", icon: "building.columns.fill")
                            SubjectRow(title: "SUS", icon: "cross.case.fill")
                        }
                        .padding(20)
                        .kepleraeGlass(intensity: intensity, cornerRadius: 30)
                    }
                    .padding(20)
                }
                .scrollIndicators(.hidden)
            }
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct SettingsView: View {
    @AppStorage("glassIntensityPercent") private var glassIntensityPercent = 75

    private var intensity: Double {
        Double(glassIntensityPercent) / 100.0
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AmbientBackground()

                ScrollView {
                    VStack(spacing: 22) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Liquid Glass")
                                .font(.title2.bold())
                            Text("Escolha a intensidade visual usando a roda abaixo.")
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)

                        VStack(spacing: 8) {
                            Text("\(glassIntensityPercent)%")
                                .font(.system(size: 34, weight: .semibold, design: .rounded))

                            Picker("Intensidade do Liquid Glass", selection: $glassIntensityPercent) {
                                ForEach(Array(stride(from: 0, through: 100, by: 10)), id: \.self) { value in
                                    Text("\(value)%")
                                        .tag(value)
                                }
                            }
                            .pickerStyle(.wheel)
                            .frame(height: 150)
                            .clipped()
                        }
                        .padding(20)
                        .kepleraeGlass(intensity: intensity, cornerRadius: 30)

                        VStack(alignment: .leading, spacing: 12) {
                            Label("Prévia", systemImage: "sparkles")
                                .font(.headline)
                            Text("A intensidade altera a presença visual do vidro, o contorno, a sombra e o brilho, mantendo o Liquid Glass do sistema.")
                                .foregroundStyle(.secondary)
                        }
                        .padding(20)
                        .kepleraeGlass(intensity: intensity, cornerRadius: 30)
                    }
                    .padding(20)
                }
            }
            .navigationTitle("Ajustes")
        }
    }
}

struct StudyCard: View {
    let section: StudySection
    let intensity: Double

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Image(systemName: section.icon)
                .font(.system(size: 28, weight: .semibold))
                .symbolRenderingMode(.hierarchical)

            Spacer(minLength: 8)

            VStack(alignment: .leading, spacing: 4) {
                Text(section.title)
                    .font(.headline)
                Text(section.subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
        }
        .frame(maxWidth: .infinity, minHeight: 138, alignment: .leading)
        .padding(18)
        .kepleraeGlass(intensity: intensity, cornerRadius: 28)
    }
}

struct SubjectRow: View {
    let title: String
    let icon: String

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .frame(width: 28)
            Text(title)
                .font(.body.weight(.medium))
            Spacer()
            Image(systemName: "chevron.right")
                .font(.caption.bold())
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 6)
    }
}

struct StudySectionView: View {
    let section: StudySection
    @AppStorage("glassIntensityPercent") private var glassIntensityPercent = 75

    private var intensity: Double {
        Double(glassIntensityPercent) / 100.0
    }

    var body: some View {
        ZStack {
            AmbientBackground()

            VStack(spacing: 18) {
                Image(systemName: section.icon)
                    .font(.system(size: 42, weight: .semibold))
                Text(section.title)
                    .font(.largeTitle.bold())
                Text("Estrutura pronta para receber a lógica correspondente da versão Android.")
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
            }
            .padding(28)
            .kepleraeGlass(intensity: intensity, cornerRadius: 32)
            .padding(20)
        }
        .navigationTitle(section.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct AmbientBackground: View {
    var body: some View {
        LinearGradient(
            colors: [
                Color(uiColor: .systemBackground),
                Color(uiColor: .secondarySystemBackground),
                Color(uiColor: .systemBackground)
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
    }
}

struct StudySection: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let subtitle: String
    let icon: String
}

private struct KepleraeGlassModifier: ViewModifier {
    let intensity: Double
    let cornerRadius: CGFloat

    func body(content: Content) -> some View {
        let normalized = min(max(intensity, 0), 1)
        let glass = normalized < 0.35 ? Glass.clear : Glass.regular
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)

        content
            .glassEffect(glass.interactive(true), in: shape)
            .overlay {
                shape
                    .stroke(
                        Color.white.opacity(0.08 + (0.28 * normalized)),
                        lineWidth: 0.8 + (0.7 * normalized)
                    )
            }
            .shadow(
                color: Color.black.opacity(0.04 + (0.14 * normalized)),
                radius: 5 + (18 * normalized),
                y: 2 + (8 * normalized)
            )
    }
}

extension View {
    func kepleraeGlass(intensity: Double, cornerRadius: CGFloat = 28) -> some View {
        modifier(KepleraeGlassModifier(intensity: intensity, cornerRadius: cornerRadius))
    }
}
